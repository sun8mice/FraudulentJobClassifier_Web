TODO
====

* Messages include template
* Pagination include template
* i18n / trans tags
